﻿namespace EBookDashboard.Models.DTO
{
    public class TextRequest
    {
        public string? Text { get; set; } = string.Empty;
    }
}
