﻿namespace EBookDashboard.Models.DTO
{
    public class ExportPdfDto
    {
        public string? Html { get; set; } = string.Empty;
    }
}
